#include <iostream>
#include <string>
#include <vector>
#include <fstream>
using namespace std;

//Shows countries on menu
void showCountries(vector<string> name1) {
  cout << "These are all 5 countries so far:" << endl;
  for (int i = 0; i < name1.size(); i++) {
    cout << "\t" << name1.at(i) << endl;
  }
}

//Shows countries and populations on menu
void showPopulations(vector<string> name1, vector<int> pop1) {
  cout << "These are all 5 populations so far:" << endl;
  for (int i = 0; i < name1.size(); i++) {
    cout << "\t" << name1.at(i) << endl;
    cout << "\t" << pop1.at(i) << endl;
  }
}

//Shows menu
void printMenu() {
  
  // print menu
    cout << "**************************************" << endl;
    cout << "*   PopGuessr: Population Guesser!   *" << endl;
    cout << "* Press number to start:             *" << endl;
    cout << "*   - 'C': Show countries            *" << endl;
    cout << "*   - 'P': Show populations          *" << endl;
    cout << "*   - 'Q': Quit the game             *" << endl;
    cout << "**************************************" << endl;
}

void initialize_data(vector<string>& name1, vector<int>& pop1) {
  
  ifstream fin;
  string temp_s;
  int temp_i;

  fin.open("worldpop.txt");
  if (fin.is_open()) {
    while (!fin.eof()) {
      fin >> temp_s;
      name1.push_back(temp_s);
      fin >> temp_i;
      pop1.push_back(temp_i);
    }
    fin.close();
    cout << "Initialized " << name1.size() << "population" << endl;
  }
  else {
    cout << "Error: Not able to read the file!" << endl;
  }
}

void save_date(vector<string> name1, vector<int> pop1) {
  ofstream fout;
  fout.open("saved_data.txt");
  if (fout.is_open()) {
    for (int i = 0; i < name1.size(); i++) {
      fout << name1.at(i) << ", " << pop1.at(i) << endl;
    }
    fout.close();
  }
  else {
    cout << "Error while saving..." << endl;
  }
}

int main() {

  char user_input;
  
  vector<string> name1;
  //vector<string> name2;
  //vector<string> name3;
  //vector<string> name4;
  //vector<string> name5;
  vector<int> pop1;
  //vector<int> pop2;
  //vector<int> pop3;
  //vector<int> pop4;
  //vector<int> pop5;

  initialize_data(name1, pop1);

  do {
    printMenu();
    cin >> user_input;
    switch(user_input) {
      case 'C':
      case 'c':
        showCountries(name1);
        //cout << "\n" << name1 << " " << name2 << " " << name3 << " " << name4 << " " << name5 << endl;
        break;
      case 'P':
      case 'p':
        showPopulations(name1, pop1);
        break;
      case 'Q':
      case 'q':
        cout << "Hope to see you play again!" << endl;
        save_date(name1, pop1);
        break;
      default:
        cout << "Invalid option, please enter another character" << endl;
        break;
    }
  } while(user_input != 'Q');
  
  //Open the file
  /*ifstream file_in;
  string name1, name2, name3, name4, name5;
  int pop1, pop2, pop3, pop4, pop5;

  file_in.open("worldpop.txt");
  if (file_in.is_open()) {
    cout << "File's currently working!" << endl;
    file_in >> name1;
    file_in >> pop1;
    file_in >> name2;
    file_in >> pop2;
    file_in >> name3;
    file_in >> pop3;
    file_in >> name4;
    file_in >> pop4;
    file_in >> name5;
    file_in >> pop5;

    cout << name1 << "'s population is " << pop1 << endl;
    cout << name2 << "'s population is " << pop2 << endl;
    cout << name3 << "'s population is " << pop3 << endl;
    cout << name4 << "'s population is " << pop4 << endl;
    cout << name5 << "'s population is " << pop5 << endl;
    cout << name6 << "'s population is " << pop6 << endl;
    cout << name7 << "'s population is " << pop7 << endl;
    cout << name8 << "'s population is " << pop8 << endl;
    cout << name9 << "'s population is " << pop9 << endl;
    cout << name10 << "'s population is " << pop10 << endl;
    cout << name11 << "'s population is " << pop11 << endl;

    file_in.close();
  }
  else {
    cout << "Could not read the file!" << endl;
  }

  //Close the file
  ofstream file_out;

  file_out.open("results.txt");
  if (file_out.is_open()) {
    file_out << "This is the result" << endl;
    file_out << "No more countries nor populations recorded" << endl;
    file_out.close();
  }
  else {
    cout << "Error while writing to file" << endl;
  }*/

  return 0;
}