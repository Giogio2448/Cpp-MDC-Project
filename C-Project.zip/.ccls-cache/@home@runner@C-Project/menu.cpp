/*#include <iostream>
#include <string>
using namespace std;

void printMenu() {

  char user_input;
  do {
    // print menu
    cout << "**************************************" << endl;
    cout << "*   PopGuessr: Population Guesser!   *" << endl;
    cout << "* Enter number of players:           *" << endl;
    cout << "*   - 1: One player joining          *" << endl;
    cout << "*   - 2: Two players joining         *" << endl;
    cout << "*   - 3: Three players joining       *" << endl;
    cout << "*   - 4: Four players joining        *" << endl;
    cout << "*   - 0: Quit the game               *" << endl;
    cout << "**************************************" << endl;
    // get user input
    cin >> user_input;

    // choose a branch depending on the input
    switch (user_input) {
    case 1:
      cout << "Player One will be joining the game." << endl;
      break;
    case 2:
      cout << "Players One and Two will be joining the game." << endl;
      break;
      case 3:
      cout << "Players One, Two, and Three will be joining the game." << endl;
      break;
    case 4:
      cout << "Players One, Two, Three, and Four will be joining the game." << endl;
      break;
    case 0:
      cout << "Zero players will be joining the game. Quit" << endl;
      break;
    default:
      cout << "Not enough/Too much players" << endl;
      break;
    }

  } while (user_input != '0');

  return 0;
}*/